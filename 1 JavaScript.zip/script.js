var nomeAluno = "Jhenifer da Silva Mestiço"; 
var idade = 18;  /*ok*/
document.write("Nome:" + nomeAluno + "Idade:" + idade );